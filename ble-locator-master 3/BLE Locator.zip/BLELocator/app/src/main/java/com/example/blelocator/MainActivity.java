package com.example.blelocator;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "iBeacon";
    private static final long SCAN_PERIOD = 10000; //ms
    private static final String FILE_NAME = "beacons.json";
    BluetoothManager blManager;
    BluetoothAdapter blAdapter = BluetoothAdapter.getDefaultAdapter();
    BluetoothLeScanner blLeScanner = blAdapter.getBluetoothLeScanner();
    Handler mHandler = new Handler();
    private boolean scanningEnd = false;
    private static final String beaconSimMac = "75:48:F1:82:33:55";
    private Context context;


    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG+" RESULT ", "testOnCreate");
        blManager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        blAdapter = blManager.getAdapter();

        if (!blAdapter.isEnabled()) {
            blAdapter.enable();

        }
        scanLeDevice();

        /*try {
            JSONObject beaconsJSON = readJsonFile();
            Log.d(TAG+ " JSON ", String.valueOf(beaconsJSON));
        } catch (IOException e) {
            e.printStackTrace();
        }*/

    }

    private void scanLeDevice() {
        if(!scanningEnd){
            Log.d(TAG+" StartScan ", "====================================================================================================================");
            blLeScanner.startScan(mLeScanCallback);
        } else {

            blLeScanner.stopScan(mLeScanCallback);
        }

    }

    private final ScanCallback mLeScanCallback = new ScanCallback() {


        @RequiresApi(api = Build.VERSION_CODES.O)
        @Override
        public void onScanResult(int callbackType, ScanResult result) {
            super.onScanResult(callbackType, result);
            String resMac = String.valueOf(result.getDevice());
            if (resMac == beaconSimMac){
                Log.d(TAG+" RESULT", "\n +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ = MATCH = +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
                Log.d(TAG+" RESULT ", "\n Device: " + result.getDevice() + "\n RSSI: " + result.getRssi() + "\n TX Power: " + result.getTxPower() + "\n AD Sid: " + result.getAdvertisingSid() + "\n Data Status: " + result.getDataStatus() + "\n Primary: " + result.getPrimaryPhy() + "\n Secondary: " + result.getSecondaryPhy() + "\n Timestamps: " + result.getTimestampNanos());
            } else {
                Log.d(TAG+" RESULT ", "\n Device: " + result.getDevice() + "\n RSSI: " + result.getRssi() + "\n TX Power: " + result.getTxPower() + "\n AD Sid: " + result.getAdvertisingSid() + "\n Data Status: " + result.getDataStatus() + "\n Primary: " + result.getPrimaryPhy() + "\n Secondary: " + result.getSecondaryPhy() + "\n Timestamps: " + result.getTimestampNanos());
            }

            try {
                TimeUnit.MILLISECONDS.sleep(2000);
            }
            catch (Exception e) {
                System.out.println("Oops! Something went wrong!");
            }
        }

        @Override
        public void onScanFailed(int errorCode) {
            super.onScanFailed(errorCode);
            Log.i(TAG+" FAIL ", String.valueOf(errorCode));
        }
    };

    private JSONObject readJsonFile() throws IOException {
        File file = new File(getFilesDir(), FILE_NAME);
        FileReader fileReader = new FileReader(file);
        BufferedReader bufferedReader = new BufferedReader(fileReader);
        StringBuilder stringBuilder = new StringBuilder();
        String line = bufferedReader.readLine();
        while (line != null){
            stringBuilder.append(line).append("\n");
            line = bufferedReader.readLine();
        }
        bufferedReader.close();

        String response = stringBuilder.toString();

        try {
            JSONObject jsonObject = new JSONObject(response);
            return jsonObject;
        }catch (JSONException err){
            Log.d("Error", err.toString());
        }

        return null;
    }

}